﻿using UnityEngine;
using System.Collections;

public class Variable : MonoBehaviour {

     public static Vector3 Player1_position;
     public static Vector3 Player2_position;
    static public bool char_flag;
}
