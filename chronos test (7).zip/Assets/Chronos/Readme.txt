Thank you for downloading Chronos!

The documentation, tutorial, migration guide, changelog and
limitations list are available online.

Tutorial:
http://ludiq.io/chronos/tutorial

Documentation:
http://ludiq.io/chronos/documentation

Migration Guide:
http://ludiq.io/chronos/migration

Limitations List:
http://ludiq.io/chronos/limitations

Changelog:
http://ludiq.io/chronos/changelog

Cached PDF versions are included in the package in case you
don't have a stable internet connection. However, the
online versions are easier to navigate and always up to date.
The PDF versions are only updated at minor version changes.

Happy time control!

- ludiq
