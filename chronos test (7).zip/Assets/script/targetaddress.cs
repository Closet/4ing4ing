﻿using UnityEngine;
using System.Collections;

public class targetaddress : MonoBehaviour {
    public  int targetsize;
    public  GameObject[] target_address;
   
    // Use this for initialization
    void Start () {
        Debug.Log(targetsize);
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
