namespace Chronos
{
	public enum Severity
	{
		Ignore,
		Warn,
		Error
	}
}
